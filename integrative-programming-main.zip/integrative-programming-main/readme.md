# Integrative Programming

## Prerequisites
We will need a basic knowledge of:

* JavaScript
* Node JS
* REST API
* Client to server communication

## Preparation
Make sure this following tools installed in our machine:

* Node JS
* NPM/Yarn (package manager)

![check](img/check-installation.png)

## What will we learn?
* [gRPC API & Protobuf](./grpc-nodejs)
* Web Socket